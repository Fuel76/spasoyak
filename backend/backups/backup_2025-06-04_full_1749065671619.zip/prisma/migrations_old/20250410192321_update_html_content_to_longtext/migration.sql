-- AlterTable
ALTER TABLE `news` MODIFY `htmlContent` LONGTEXT NULL;
