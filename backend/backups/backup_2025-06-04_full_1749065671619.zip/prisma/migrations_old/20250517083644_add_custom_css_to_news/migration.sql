-- AlterTable
ALTER TABLE `news` ADD COLUMN `customCss` LONGTEXT NULL;
