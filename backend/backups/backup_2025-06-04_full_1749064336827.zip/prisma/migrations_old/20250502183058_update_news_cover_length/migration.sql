-- AlterTable
ALTER TABLE `news` MODIFY `cover` TEXT NULL;
